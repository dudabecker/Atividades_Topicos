package br.ifpr.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudClienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudClienteApplication.class, args);
	}

}
