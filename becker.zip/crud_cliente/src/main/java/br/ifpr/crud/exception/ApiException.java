package br.ifpr.crud.exception;

public class ApiException extends RuntimeException {

	private static final long serialVersionUID = 6886821659924675947L;

	public ApiException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
