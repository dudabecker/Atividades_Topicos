package br.ifpr.crud.exception;

public class NegocioException extends RuntimeException  {

	private static final long serialVersionUID = -8319284939805103392L;

	public NegocioException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
